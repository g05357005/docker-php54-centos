<!DOCTYPE html>
<html>
<head>
<title>Apache with PHP Support - CentOS 7</title>
<style>
    body {
        text-align: center;
        font-family: Tahoma, Geneva, Verdana, sans-serif;
    }
</style>
</head>
<body>
<h1>Apache with PHP Support.</h1>
<p>If you see PHP info below, Apache with PHP container works.</p>

<?php 

   phpinfo()
   
?>
</body>
</html>
